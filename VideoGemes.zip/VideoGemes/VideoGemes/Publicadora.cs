﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoGemes
{
    class Publicadora
    {
        public string fundacao { get; set; }
        public int ID { get; set; }
        public string nome { get; set; }
    }
}
