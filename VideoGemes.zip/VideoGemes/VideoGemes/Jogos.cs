﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoGemes
{
    class Jogos
    {
        public string Developer { get; set; }
        public string release_date { get; set; }
        public string genero { get; set; }
        public int ID_motor { get; set; }
        public int ID { get; set; }
        public int ID_publi { get; set; }
        public int Vendas { get; set; }
        public string nome { get; set; }
    }
}
