﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoGemes
{
    class Motor
    {
        public int ID { get; set; }
        public string nome { get; set; }
    }
}
